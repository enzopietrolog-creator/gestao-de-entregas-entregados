from flask import Flask, request, redirect, render_template_string

app = Flask(__name__)

entregas = []

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Controle de Entregas</title>
    <style>
        body { font-family: Arial; margin: 40px; background: #f4f4f4; }
        h1 { color: #333; }
        form { margin-bottom: 20px; }
        input { padding: 8px; margin: 5px; }
        button { padding: 8px 12px; background: #28a745; color: white; border: none; }
        table { width: 100%; background: white; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background: #007bff; color: white; }
    </style>
</head>
<body>

<h1>🚚 Sistema de Controle de Entregas</h1>

<form method="POST">
    <input name="cliente" placeholder="Cliente" required>
    <input name="origem" placeholder="Origem" required>
    <input name="destino" placeholder="Destino" required>
    <input name="valor" placeholder="Valor do Frete" required>
    <button type="submit">Adicionar</button>
</form>

<table>
    <tr>
        <th>Cliente</th>
        <th>Origem</th>
        <th>Destino</th>
        <th>Valor</th>
    </tr>
    {% for entrega in entregas %}
    <tr>
        <td>{{ entrega.cliente }}</td>
        <td>{{ entrega.origem }}</td>
        <td>{{ entrega.destino }}</td>
        <td>R$ {{ entrega.valor }}</td>
    </tr>
    {% endfor %}
</table>

</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        entregas.append({
            "cliente": request.form["cliente"],
            "origem": request.form["origem"],
            "destino": request.form["destino"],
            "valor": request.form["valor"],
        })
        return redirect("/")

    return render_template_string(HTML, entregas=entregas)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
