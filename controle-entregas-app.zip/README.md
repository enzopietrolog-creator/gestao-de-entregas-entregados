# 🚚 Controle de Entregas

Sistema simples de controle de entregas em uma única página.

## 🚀 Executar localmente

pip install -r requirements.txt  
python main.py

## 🐳 Executar com Docker

docker build -t controle-entregas .  
docker run -p 8000:8000 controle-entregas

## 🌍 Deploy

Projeto pronto para deploy no Railway usando Docker.
